jQuery(document).ready(function ($) {
    $('.color-field').wpColorPicker(); // Initialize the color picker for fields with the 'color-field' class
});
