<?php return array('dependencies' => array('lodash', 'wp-url'), 'version' => '65d6f5310df5828e9a2b');
